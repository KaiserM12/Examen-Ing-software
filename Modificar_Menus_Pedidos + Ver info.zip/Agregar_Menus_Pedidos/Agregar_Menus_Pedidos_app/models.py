from django.db import models

from django.db import models

class Mesa(models.Model):
    numero = models.IntegerField(unique=True)
    estado = models.CharField(max_length=20, default='LIBRE')
    
    def __str__(self):
        return f"Mesa {self.numero} ({self.estado})"

class Cliente(models.Model):
    nombre = models.CharField(max_length=100)
    telefono = models.CharField(max_length=20, blank=True, null=True)

    def __str__(self):
        return self.nombre

class Producto(models.Model):
    nombre = models.CharField(max_length=100)
    precio = models.DecimalField(max_digits=10, decimal_places=2)
    categoria = models.CharField(max_length=50)
    disponible = models.BooleanField(default=True) # Para la validación de inventario

    def __str__(self):
        return self.nombre

class Pedido(models.Model):
    # Relacionado a HU-CM-02 (Inicio)
    mesa = models.ForeignKey(Mesa, on_delete=models.SET_NULL, null=True, blank=True)
    cliente = models.ForeignKey(Cliente, on_delete=models.SET_NULL, null=True, blank=True)
    
    # Atributo de estado para el ciclo de vida (HU-CM-05, HU-CM-09)
    estado = models.CharField(max_length=50, default='ACTIVO') 
    
    fecha_creacion = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return f"Pedido #{self.id} en Mesa {self.mesa.numero if self.mesa else 'N/A'}"
    
    @property
    def subtotal(self):
        # Método para calcular el subtotal (Criterio de Aceptación HU-CM-03)
        return sum(item.total_linea for item in self.detalles.all())

class DetallePedido(models.Model):
    # Relación de Composición (un detalle pertenece a un pedido)
    pedido = models.ForeignKey(Pedido, related_name='detalles', on_delete=models.CASCADE)
    
    # Relación de Asociación (un detalle apunta a un producto)
    producto = models.ForeignKey(Producto, on_delete=models.PROTECT) 
    
    cantidad = models.IntegerField(default=1) # Cantidad por defecto de 1 (Criterio HU-CM-03)
    precio_unitario_guardado = models.DecimalField(max_digits=10, decimal_places=2) # Para guardar el precio al momento del pedido
    
    def save(self, *args, **kwargs):
        # Guardamos el precio actual del producto al crear el detalle
        if not self.pk:
            self.precio_unitario_guardado = self.producto.precio
        super().save(*args, **kwargs)

    @property
    def total_linea(self):
        return self.cantidad * self.precio_unitario_guardado

    def __str__(self):
        return f"{self.cantidad}x {self.producto.nombre}"
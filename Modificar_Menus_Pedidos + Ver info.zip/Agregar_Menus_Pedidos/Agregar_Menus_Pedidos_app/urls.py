# Archivo: Agregar_Menus_Pedidos_app/urls.py

from django.urls import path
from . import views

urlpatterns = [
    # Ruta para ver la interfaz de toma de pedidos
    path('pedido/<int:pedido_id>/', views.vista_toma_pedido, name='toma_pedido'),
    
    # Ruta (endpoint) para agregar productos al pedido
    path('pedido/<int:pedido_id>/agregar/', views.agregar_producto_a_pedido, name='agregar_producto'),

    path('pedido/<int:pedido_id>/modificar/', views.modificar_cantidad_producto, name='modificar_producto'),
    path('producto/<int:producto_id>/info/', views.obtener_info_producto, name='info_producto'),
]
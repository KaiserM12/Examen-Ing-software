from django.shortcuts import render
from .forms import FormCliente, FormAsignacion

def index(request):
    """Renderiza la página HTML principal"""
    return render(request, 'index.html')

def agregarCliente(request):
    form = FormCliente()
    if request.method == 'POST':
        form = FormCliente(request.POST)
        if form.is_valid():
            form.save()
        return index(request)
    data = {'form' : form}
    return render(request, 'agregar_clientes.html', data)

def agregarAsignacion(request):
    form = FormAsignacion()
    if request.method == 'POST':
        form = FormAsignacion(request.POST)
        if form.is_valid():
            form.save()
        return index(request)
    data = {'form' : form}
    return render(request, 'agregar_asignaciones.html', data)
from django.urls import path
from . import views

urlpatterns = [
    path('', views.index, name='index'),
    path('agregarCliente/', views.agregarCliente),
    path('agregarAsignacion/', views.agregarAsignacion),
]
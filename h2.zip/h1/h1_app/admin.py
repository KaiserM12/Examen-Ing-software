from django.contrib import admin
from .models import Cliente, Mesa, Asignacion

@admin.register(Cliente)
class ClienteAdmin(admin.ModelAdmin):
    list_display = ['nombre', 'genero', 'pedido_horas']
    list_filter = ['genero']
    search_fields = ['nombre']

@admin.register(Mesa)
class MesaAdmin(admin.ModelAdmin):
    list_display = ['numero_mesa', 'capacidad', 'estado']
    list_filter = ['estado']

@admin.register(Asignacion)
class AsignacionAdmin(admin.ModelAdmin):
    list_display = ['cliente', 'mesa', 'hora_inicio', 'activa']
    list_filter = ['activa', 'hora_inicio']
    search_fields = ['cliente__nombre']

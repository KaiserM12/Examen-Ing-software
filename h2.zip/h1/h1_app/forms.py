from django import forms
from .models import Cliente, Asignacion

class FormCliente(forms.ModelForm):
    class Meta:
        model = Cliente
        fields = '__all__'

class FormAsignacion(forms.ModelForm):
    class Meta:
        model = Asignacion
        fields = '__all__'
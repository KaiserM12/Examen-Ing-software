from django.urls import path
from . import views

urlpatterns = [
    path('', views.index, name='index'),
    path('api/clientes/', views.obtener_clientes, name='api_clientes'),
    path('api/mesas/', views.obtener_mesas, name='api_mesas'),
    path('api/asignaciones/', views.obtener_asignaciones, name='api_asignaciones'),
    path('api/asignar/', views.asignar_mesa, name='api_asignar'),
    path('api/liberar/', views.liberar_mesa, name='api_liberar'),
]
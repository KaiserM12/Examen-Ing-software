from django.db import models
from django.utils import timezone

class Cliente(models.Model):
    GENERO_CHOICES = [
        ('M', 'Masculino'),
        ('F', 'Femenino'),
    ]
    
    nombre = models.CharField(max_length=100)
    genero = models.CharField(max_length=1, choices=GENERO_CHOICES)
    pedido_horas = models.IntegerField()
    
    class Meta:
        db_table = 'clientes'
    
    def __str__(self):
        return f"{self.nombre} - {self.pedido_horas}hrs"


class Mesa(models.Model):
    ESTADO_CHOICES = [
        ('disponible', 'Disponible'),
        ('ocupada', 'Ocupada'),
    ]
    
    numero_mesa = models.IntegerField(unique=True)
    capacidad = models.IntegerField(default=4)
    estado = models.CharField(max_length=20, choices=ESTADO_CHOICES, default='disponible')
    
    class Meta:
        db_table = 'mesas'
    
    def __str__(self):
        return f"Mesa {self.numero_mesa}"


class Asignacion(models.Model):
    cliente = models.ForeignKey(Cliente, on_delete=models.CASCADE)
    mesa = models.ForeignKey(Mesa, on_delete=models.CASCADE)
    hora_inicio = models.DateTimeField(default=timezone.now)
    activa = models.BooleanField(default=True)
    
    class Meta:
        db_table = 'asignaciones'
    
    def __str__(self):
        return f"{self.cliente.nombre} - Mesa {self.mesa.numero_mesa}"


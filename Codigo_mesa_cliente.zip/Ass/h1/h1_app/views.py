from django.shortcuts import render
from django.http import JsonResponse
from django.views.decorators.csrf import csrf_exempt
from django.views.decorators.http import require_http_methods
import json
from .models import Cliente, Mesa, Asignacion

def index(request):
    """Renderiza la página HTML principal"""
    return render(request, 'index.html')

@require_http_methods(["GET"])
def obtener_clientes(request):
    """API: Obtener todos los clientes"""
    clientes = Cliente.objects.all().values('id', 'nombre', 'genero', 'pedido_horas')
    
    # Agregar si tiene asignación activa
    clientes_list = []
    for cliente in clientes:
        tiene_asignacion = Asignacion.objects.filter(
            cliente_id=cliente['id'],
            activa=True
        ).exists()
        cliente['tiene_asignacion'] = tiene_asignacion
        clientes_list.append(cliente)
    
    return JsonResponse({'clientes': clientes_list})

@require_http_methods(["GET"])
def obtener_mesas(request):
    """API: Obtener todas las mesas"""
    mesas = Mesa.objects.all().values('id', 'numero_mesa', 'capacidad', 'estado')
    return JsonResponse({'mesas': list(mesas)})

@require_http_methods(["GET"])
def obtener_asignaciones(request):
    """API: Obtener asignaciones activas"""
    asignaciones = Asignacion.objects.filter(activa=True).select_related('cliente', 'mesa')
    
    asignaciones_list = []
    for asig in asignaciones:
        asignaciones_list.append({
            'id': asig.id,
            'cliente_nombre': asig.cliente.nombre,
            'mesa_numero': asig.mesa.numero_mesa,
            'pedido_horas': asig.cliente.pedido_horas,
            'hora_inicio': asig.hora_inicio.isoformat()
        })
    
    return JsonResponse({'asignaciones': asignaciones_list})

@csrf_exempt
@require_http_methods(["POST"])
def asignar_mesa(request):
    """API: Asignar una mesa a un cliente"""
    try:
        data = json.loads(request.body)
        cliente_id = data.get('cliente_id')
        mesa_id = data.get('mesa_id')
        
        # Validaciones
        cliente = Cliente.objects.get(id=cliente_id)
        mesa = Mesa.objects.get(id=mesa_id)
        
        # Verificar si el cliente ya tiene asignación
        if Asignacion.objects.filter(cliente=cliente, activa=True).exists():
            return JsonResponse({
                'success': False,
                'error': 'El cliente ya tiene una mesa asignada'
            }, status=400)
        
        # Verificar si la mesa está disponible
        if mesa.estado != 'disponible':
            return JsonResponse({
                'success': False,
                'error': 'La mesa no está disponible'
            }, status=400)
        
        # Crear asignación
        asignacion = Asignacion.objects.create(
            cliente=cliente,
            mesa=mesa,
            activa=True
        )
        
        # Cambiar estado de la mesa
        mesa.estado = 'ocupada'
        mesa.save()
        
        return JsonResponse({
            'success': True,
            'message': 'Mesa asignada exitosamente',
            'asignacion_id': asignacion.id
        })
        
    except Cliente.DoesNotExist:
        return JsonResponse({'success': False, 'error': 'Cliente no encontrado'}, status=404)
    except Mesa.DoesNotExist:
        return JsonResponse({'success': False, 'error': 'Mesa no encontrada'}, status=404)
    except Exception as e:
        return JsonResponse({'success': False, 'error': str(e)}, status=500)

@csrf_exempt
@require_http_methods(["POST"])
def liberar_mesa(request):
    """API: Liberar una mesa"""
    try:
        data = json.loads(request.body)
        asignacion_id = data.get('asignacion_id')
        
        asignacion = Asignacion.objects.get(id=asignacion_id, activa=True)
        mesa = asignacion.mesa
        
        # Desactivar asignación
        asignacion.activa = False
        asignacion.save()
        
        # Liberar mesa
        mesa.estado = 'disponible'
        mesa.save()
        
        return JsonResponse({
            'success': True,
            'message': 'Mesa liberada exitosamente'
        })
        
    except Asignacion.DoesNotExist:
        return JsonResponse({'success': False, 'error': 'Asignación no encontrada'}, status=404)
    except Exception as e:
        return JsonResponse({'success': False, 'error': str(e)}, status=500)
# pedidos/urls.py (MODIFICADO)

from django.contrib import admin
from django.urls import path
from django.conf import settings
from django.conf.urls.static import static
from mainapp import views 

urlpatterns = [
    path('admin/', admin.site.urls),
    
    # Ruta de inicio para ver la lista de pedidos
    path('', views.home, name='home'),
    
    # Ruta de detalle para un pedido específico (usando el ID del pedido)
    path('pedido/<int:pedido_id>/', views.pedido_detalle, name='pedido_detalle'),
]

# Configuración para servir archivos de media en desarrollo
if settings.DEBUG:
    urlpatterns += static(settings.MEDIA_URL, document_root=settings.MEDIA_ROOT)
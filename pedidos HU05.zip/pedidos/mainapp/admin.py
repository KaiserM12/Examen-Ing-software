# mainapp/admin.py (Versión Pedidos)

from django.contrib import admin
from .models import Pedido, LineaPedido, Producto

# Inline para poder agregar LineasDePedido dentro del formulario de Pedido
class LineaPedidoInline(admin.TabularInline):
    model = LineaPedido
    extra = 1
    # 'subtotal' es un campo de solo lectura calculado en el modelo
    readonly_fields = ('subtotal', 'precio_unitario',)
    fields = ('producto', 'cantidad', 'precio_unitario', 'subtotal')
    
    # Pre-cargar el precio unitario del producto seleccionado (opcional)
    def formfield_for_foreignkey(self, db_field, request, **kwargs):
        if db_field.name == "producto":
            kwargs["queryset"] = Producto.objects.all()
        return super().formfield_for_foreignkey(db_field, request, **kwargs)


class ProductoAdmin(admin.ModelAdmin):
    list_display = ('nombre', 'precio',)
    search_fields = ('nombre', 'descripcion',)
    prepopulated_fields = {'slug': ('nombre',)}

class PedidoAdmin(admin.ModelAdmin):
    # 'total_pedido' es la función que definimos en models.py
    list_display = ('id', 'nombre_cliente', 'contacto_cliente', 'fecha_pedido', 'estado', 'total_pedido')
    list_filter = ('estado', 'fecha_pedido')
    search_fields = ('nombre_cliente', 'contacto_cliente', 'direccion',)
    
    # Usamos el Inline para los ítems del pedido
    inlines = [LineaPedidoInline]


# Registro de modelos
admin.site.register(Producto, ProductoAdmin)
admin.site.register(Pedido, PedidoAdmin)
# mainapp/views.py (Versión Pedidos)

from django.shortcuts import render, get_object_or_404
from .models import Pedido

def home(request):
    # Obtiene todos los pedidos, ordenados por fecha descendente
    pedidos = Pedido.objects.all().order_by('-fecha_pedido')
    context = {'pedidos': pedidos}
    return render(request, 'home.html', context)

def pedido_detalle(request, pedido_id):
    # Obtiene el pedido por ID
    pedido = get_object_or_404(Pedido, pk=pedido_id)
    
    # Obtiene las líneas de pedido relacionadas (los ítems)
    items = pedido.lineapedido_set.all()
    
    context = {
        'pedido': pedido,
        'items': items,
    }
    # Usaremos el template 'pedidodetalle.html' para evitar conflictos con 'rifadetalle.html'
    return render(request, 'pedidodetalle.html', context)
# mainapp/models.py (Versión Pedidos)

from django.db import models
from django.utils.text import slugify

# Opciones para el estado del pedido
ESTADO_PEDIDO = (
    ('PENDIENTE', 'Pendiente'),
    ('EN_PREPARACION', 'En Preparación'),
    ('ENVIADO', 'Enviado'),
    ('ENTREGADO', 'Entregado'),
    ('CANCELADO', 'Cancelado'),
)

class Producto(models.Model):
    nombre = models.CharField(max_length=100)
    slug = models.SlugField(unique=True, blank=True)
    descripcion = models.TextField(blank=True, null=True)
    precio = models.DecimalField(max_digits=10, decimal_places=2, default=0.00)

    def save(self, *args, **kwargs):
        if not self.slug:
            self.slug = slugify(self.nombre)
        super().save(*args, **kwargs)

    def __str__(self):
        return self.nombre


class Pedido(models.Model):
    nombre_cliente = models.CharField(max_length=200)
    contacto_cliente = models.CharField(max_length=100, blank=True, null=True)
    direccion = models.TextField(blank=True, null=True)
    fecha_pedido = models.DateTimeField(auto_now_add=True)
    estado = models.CharField(max_length=20, choices=ESTADO_PEDIDO, default='PENDIENTE')
    
    # Campo calculado para mostrar el total en el admin
    def total_pedido(self):
        # Suma el subtotal de todas las líneas de pedido relacionadas
        total = sum(item.subtotal for item in self.lineapedido_set.all())
        return total
    total_pedido.short_description = 'Total'

    def __str__(self):
        return f'Pedido #{self.id} de {self.nombre_cliente}'

class LineaPedido(models.Model):
    # Relación con el pedido al que pertenece
    pedido = models.ForeignKey(Pedido, on_delete=models.CASCADE)
    # El producto que se pidió
    producto = models.ForeignKey(Producto, on_delete=models.CASCADE)
    cantidad = models.PositiveIntegerField(default=1)
    precio_unitario = models.DecimalField(max_digits=10, decimal_places=2, default=0.00)
    
    @property
    def subtotal(self):
        # Calcula el subtotal multiplicando cantidad por precio unitario
        return self.cantidad * self.precio_unitario

    def save(self, *args, **kwargs):
        # Asegura que se guarde el precio actual del producto al momento del pedido
        if not self.precio_unitario:
            self.precio_unitario = self.producto.precio
        super().save(*args, **kwargs)

    def __str__(self):
        return f'{self.cantidad} x {self.producto.nombre}'

from django.shortcuts import render, get_object_or_404, redirect
from django.http import JsonResponse
from .models import Pedido, Producto, DetallePedido
from django.db import transaction

# 1. Recuperar el listado de productos agrupados (Criterio HU-CM-03)
def vista_toma_pedido(request, pedido_id):
    pedido = get_object_or_404(Pedido, pk=pedido_id)
    
    # Listado de productos disponibles para la interfaz
    productos = Producto.objects.filter(disponible=True).order_by('categoria')
    
    # Agrupamos por categoría para cumplir el criterio de interfaz
    productos_por_categoria = {}
    for producto in productos:
        if producto.categoria not in productos_por_categoria:
            productos_por_categoria[producto.categoria] = []
        productos_por_categoria[producto.categoria].append(producto)
    
    context = {
        'pedido': pedido,
        'productos_por_categoria': productos_por_categoria,
        'detalles_pedido': pedido.detalles.all(),
        'subtotal_pedido': pedido.subtotal # Uso del método @property del modelo
    }
    return render(request, 'app_pedidos/toma_pedido.html', context)


# 2. CRUD: Lógica para agregar un producto (o actualizar si ya existe)
def agregar_producto_a_pedido(request, pedido_id):
    if request.method == 'POST':
        pedido = get_object_or_404(Pedido, pk=pedido_id)
        
        # Asumiendo que recibes el ID del producto y la cantidad (por defecto 1)
        producto_id = request.POST.get('producto_id')
        cantidad = int(request.POST.get('cantidad', 1)) 
        
        producto = get_object_or_404(Producto, pk=producto_id)
        
        # --- Criterio de Aceptación: No hay ingrediente, mostrar error ---
        if not producto.disponible:
            return JsonResponse({'error': 'Producto no disponible. Falta ingrediente.'}, status=400)

        with transaction.atomic():
            # Intentamos obtener el detalle si el producto ya existe en este pedido
            detalle, creado = DetallePedido.objects.get_or_create(
                pedido=pedido,
                producto=producto,
                defaults={'cantidad': cantidad}
            )

            if not creado:
                # El producto ya existía (Flujo del camino 'SÍ' del Diagrama de Actividades)
                # Esto cubre la lógica de la HU-CM-04 (Modificar cantidad) parcialmente
                detalle.cantidad += cantidad
                detalle.save()

            # La respuesta podría incluir el nuevo subtotal (Criterio de Aceptación: Cálculo y Muestra)
            return JsonResponse({
                'success': True, 
                'subtotal': pedido.subtotal,
                'mensaje': 'Producto agregado/actualizado.'
            })

    return JsonResponse({'error': 'Método no permitido.'}, status=405)